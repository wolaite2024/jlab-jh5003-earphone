#ifndef __OS_API_H__
#define __OS_API_H__

typedef struct{
    int (*dbgOutput)(const char*);
    uint64_t (*GetTimeNs)(void);
    void (*uSleep)(uint32_t);
    int (*i2cRead)(uint16_t slaveAddr, uint16_t reg, int regLength, uint8_t *readData, int readDataSize, int argument);
    int (*i2cWrite)(uint16_t slaveAddr, uint16_t reg, int regLength, uint8_t *writeData, int writeDataSize, int argument);
    int (*i2cTransfer)(uint16_t slaveAddr, uint16_t reg, int regLength, uint8_t *writeData, int writeDataSize, uint8_t *readData, int readDataSize, int argument);
} os_api;

#endif /* __OS_API_H__ */
