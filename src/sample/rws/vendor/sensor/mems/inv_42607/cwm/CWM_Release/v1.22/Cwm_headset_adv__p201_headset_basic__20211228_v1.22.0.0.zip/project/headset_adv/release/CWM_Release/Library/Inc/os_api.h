#ifndef __OS_API_H__
#define __OS_API_H__

typedef struct{
    int (*dbgOutput)(const char*);
} os_api;

#endif /* __OS_API_H__ */
