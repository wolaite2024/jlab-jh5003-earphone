#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "cwm_lib.h"
#define THIS_IS__RIGHT_EAR    1
#define THIS_IS__LEFT_EAR     2

void headset_config(int ear_side,int sensor_odr){

	SettingControl_t scl;
	ear_side = (ear_side==THIS_IS__RIGHT_EAR)?THIS_IS__RIGHT_EAR:THIS_IS__LEFT_EAR; 
	memset(&scl, 0, sizeof(scl));
	scl.iData[0] = 1;
	scl.iData[1] = -1;
	scl.iData[2] = 0;
	scl.iData[3] = 0;
	scl.iData[4] = 3;
	scl.iData[5] = 0;
	scl.iData[6] = ear_side; //ear side 
	scl.iData[7] = 0;
	scl.iData[8] = 0;
	scl.iData[9] = sensor_odr; //odr
	CWM_SettingControl(SCL_HS_ORIEN_CONFIG);

	memset(&scl, 0, sizeof(scl));
	scl.iData[0] = 1;
	scl.iData[1] = 3;
	CWM_SettingControl(SCL_INPUT_SENSOR_CONFIG);
}