#pragma once

#include "windows.h"
#include "stdint.h"
#include <BluetoothAPIs.h>
#include "bthdef.h"

#ifdef RTKANCMPEXPORT_EXPORTS
#define RTKANCMPEXPORT_API __declspec(dllexport)
#else
#define RTKANCMPEXPORT_API __declspec(dllimport)
#endif

#pragma pack(push, 1)

	enum TEST_MODE: unsigned char
	{
		NO_TEST_MODE = 0,
		ENTER_ANC_TEST_MODE = 1,
		ENTER_LLAPT_TEST_MODE = 2
	};

	struct _DEVICE_SETTING_
	{
		WCHAR devName[248];
	};

	enum DEBUG_MODE :unsigned char
	{
		DEBUG_ONE_DEVICE_MODE,
		DEBUG_TWO_DEVICE_MODE,
	};

	struct _GROUP_INFO_
	{
		uint32_t groupIndex : 3;//set 0
		uint32_t scenario : 12;
		uint32_t resv : 17;
	};

	typedef struct _BOND_DEVICE_INFO
	{
		BLUETOOTH_ADDRESS Address;                  //  Bluetooth address
		ULONG   ulClassofDevice;                    //  Bluetooth "Class of Device"
		WCHAR   szName[BLUETOOTH_MAX_NAME_SIZE];    //  Name of the device
	}BOND_DEVICE_INFO;

	enum MODE_TYPE : unsigned char
	{
		SPP_MODE,//customer com
		UART_SOC_MODE,
	};

	struct _READ_INFO_
	{
		double extLGaindB;
		double extRGaindB;
		double intLGaindB;
		double intRGaindB;
		int groupIndex;
		int groupInfo;
		unsigned char ancScenario;
	};

	struct _WRITE_INFO_
	{
		double extLGaindB;
		double extRGaindB;
		double intLGaindB;
		double intRGaindB;
		int groupIndex;
	};

	struct _BURN_INFO_
	{
		double extLGaindB;
		double extRGaindB;
		double intLGaindB;
		double intRGaindB;
		_GROUP_INFO_ groupInfo;
	};

	struct _ANC_LLAPT_READ_INFO_
	{
		double ANCExtLGaindB;
		double ANCExtRGaindB;
		double ANCIntLGaindB;
		double ANCIntRGaindB;
		double LLAPTExtLGaindB;
		double LLAPTExtRGaindB;
		int ANCGroupInfo;
		int groupIndex;
	};

	struct _ANC_LLAPT_WRITE_INFO_
	{
		double ANCExtLGaindB;
		double ANCExtRGaindB;
		double ANCIntLGaindB;
		double ANCIntRGaindB;
		double LLAPTExtLGaindB;
		double LLAPTExtRGaindB;
		int groupIndex;
	};

	struct _ANC_LLAPT_BURN_INFO_
	{
		double ANCExtLGaindB;
		double ANCExtRGaindB;
		double ANCIntLGaindB;
		double ANCIntRGaindB;
		double LLAPTExtLGaindB;
		double LLAPTExtRGaindB;
		_GROUP_INFO_ ANCGroupInfo;
	};

#define MAX_GROUP_NUM 12

	struct _LLAPT_GROUP_INFO
	{
		uint8_t GroupNumber;
		uint8_t GroupANCFlag[MAX_GROUP_NUM];
	};

	enum _ERROR_STATUS_ : int
	{
		_ERROR_STATUS_GAIN_SUCCESS = 0x00,
		_ERROR_STATUS_WB_PRIMARY_GAIN_FAIL = 0x01,
		_ERROR_STATUS_WB_SECONDARY_GAIN_FAIL = 0x02,
		_ERROR_STATUS_WB_SECONDARY_NOT_EXIST = 0x03,
		_ERROR_STATUS_WB_SECONDARY_RESPONSE_TIMEOUT = 0x04,
		_ERROR_STATUS_R_SECONDARY_RESPONSE_TIMEOUT = 0x05,
		_ERROR_STATUS_FAIL = -1,
	};

	struct _UART_SETTING_INFO_
	{
		int portIndex;
		unsigned int baudrate;
		MODE_TYPE modeType = UART_SOC_MODE;//default UART_SOC_MODE
		DEBUG_MODE debugMode;
		TEST_MODE testMode = ENTER_ANC_TEST_MODE;
	};

	struct _SPP_SETTING_INFO_
	{
		unsigned long long addr;
		DEBUG_MODE debugMode;
		TEST_MODE testMode = ENTER_ANC_TEST_MODE;
	};

	struct _DUAL_MIC_STATUS_
	{
		uint8_t physicPrimaryL_en;
		uint8_t physicSecondaryL_en;
		uint8_t physicPrimaryR_en;
		uint8_t physicSecondaryR_en;
	};

extern "C"
{

	/********************************UART***************************************/
	RTKANCMPEXPORT_API int RTKANCUpdatePortNum();

	RTKANCMPEXPORT_API int RTKANCQueryPortName(unsigned int index, OUT wchar_t *portName, int bufLength);

	typedef void(__cdecl *FUNCJOBRST2)(unsigned int portIndex, DWORD status);

	RTKANCMPEXPORT_API int RTKANCStartPort(_UART_SETTING_INFO_ info, FUNCJOBRST2 fn);

	RTKANCMPEXPORT_API int RTKANCStopPort(int portIndex, int isReset = 0);//0:exit ANC no reset 1:exit ANC and reset

	/********************************SPP*****************************************/
	typedef void(__cdecl *FUNCJOBRST)(ULONGLONG addr, DWORD status);

	RTKANCMPEXPORT_API int RTKANCOnAirGetBondDevices(bool bStart, BOND_DEVICE_INFO *vBondDev, unsigned int* pNumBondDevFound);

	RTKANCMPEXPORT_API int RTKANCBTLinkConnect(_SPP_SETTING_INFO_ info, FUNCJOBRST fn);

	RTKANCMPEXPORT_API int RTKANCBTLinkDisconnect(unsigned long long addr,int isReset = 0);

	/************************for SPP factory reset********************************/
	//1.remove all
	RTKANCMPEXPORT_API int RTKRemoveBondDeviceAll();
	//2.get device address by device name
	RTKANCMPEXPORT_API int RTKSDeviceSetting(const _DEVICE_SETTING_& config);
	RTKANCMPEXPORT_API unsigned long long RTKQueryCandidateDevice();//call more times(eg:call 5 )
	//3.inquiry by address
	RTKANCMPEXPORT_API int RTKInquiryAndFind(const ULONGLONG address, unsigned char timeMultiplier);
	//4.authrntication
	RTKANCMPEXPORT_API int RTKAutoAuthentication(ULONGLONG address);
	//4.connect
	//5.remove one device
	RTKANCMPEXPORT_API int RTKRmoveBondDevice(ULONGLONG address);

	/****************************ANC gain mismatch**********************************/
	//ENTER_ANC_TEST_MODE
	//one dongle/one uart for one earphone
	RTKANCMPEXPORT_API int RTKANCReadGaindBByCom1(
		IN const int portIndex, 
		IN const unsigned char target_sel, 
		IN OUT _READ_INFO_* info);
	RTKANCMPEXPORT_API int RTKANCReadGaindBBySPP1(
		IN const unsigned long long addr,
		IN const unsigned char target_sel,
		IN OUT _READ_INFO_* info);

	RTKANCMPEXPORT_API int RTKANCWriteGaindBByCom1(IN const int portIndex, IN const _WRITE_INFO_ info);
	RTKANCMPEXPORT_API int RTKANCWriteGaindBBySPP1(IN const unsigned long long addr, IN const _WRITE_INFO_ info);

	RTKANCMPEXPORT_API int RTKANCBurnGaindBByCom1(IN const int portIndex,IN const _BURN_INFO_ info);
	RTKANCMPEXPORT_API int RTKANCBurnGaindBBySPP1(IN const unsigned long long addr,IN const _BURN_INFO_ info);

	//one dongle/one uart for two earphone
	RTKANCMPEXPORT_API int RTKANCReadGaindBByCom2(
		IN const int portIndex, 
		IN const unsigned char target_sel, 
		IN OUT _READ_INFO_* info0, 
		IN OUT _READ_INFO_* info1);
	RTKANCMPEXPORT_API int RTKANCReadGaindBBySPP2(
		IN const unsigned long long addr, 
		IN const unsigned char target_sel,
		IN OUT _READ_INFO_* info0, 
		IN OUT _READ_INFO_* info1);

	RTKANCMPEXPORT_API int RTKANCWriteGaindBByCom2(
		IN const int portIndex, 
		IN const _WRITE_INFO_ info0, 
		IN const _WRITE_INFO_ info1);
	RTKANCMPEXPORT_API int RTKANCWriteGaindBBySPP2(
		IN const unsigned long long addr, 
		IN const _WRITE_INFO_ info0, 
		IN const _WRITE_INFO_ info1);

	RTKANCMPEXPORT_API int RTKANCBurnGaindBByCom2(
		IN const int portIndex, 
		IN const _BURN_INFO_ info0, 
		IN const _BURN_INFO_ info1);
	RTKANCMPEXPORT_API int RTKANCBurnGaindBBySPP2(
		IN const unsigned long long addr, 
		IN const _BURN_INFO_ info0, 
		IN const _BURN_INFO_ info1);


	/********************************open/close DSPAPT*********************************/
	//openport->open/close DSPAPT->closeport
	RTKANCMPEXPORT_API int RTKOpenCloseDSPAPT(
		bool status,//false:close,true:open
		int portIndex,
		unsigned int baudrate,
		MODE_TYPE modeType,
		FUNCJOBRST2 fn);	
	//RTKANCMPEXPORT_API int RTKOpenCloseDSPAPTBySPP(
	//	bool status,//false:close,true:open
	//	const unsigned long long addr,
	//	FUNCJOBRST2 fn);
	//openport->open DSPAPT
	RTKANCMPEXPORT_API int RTKOpenDSPAPT(int portIndex, unsigned int baudrate, MODE_TYPE modeType, FUNCJOBRST2 fn);		
	//close DSPAPT->closeport
	RTKANCMPEXPORT_API int RTKCloseDSPAPT(int portIndex);

	/********************************Get battery****************************************/
	RTKANCMPEXPORT_API int RTKGetBatteryByCom(IN const int portIndex, unsigned char& primaryVal,unsigned char& secondaryVal);
	RTKANCMPEXPORT_API int RTKGetBatteryBySPP(IN const unsigned long long addr, unsigned char& primaryVal, unsigned char& secondaryVal);

	/********************************Get Role*****************************************/
	//any test mode all OK
	RTKANCMPEXPORT_API int RTKGetRWSRoleByCom(IN const int portIndex, unsigned char &role);
	RTKANCMPEXPORT_API int RTKGetRWSRoleBySPP(IN const unsigned long long addr, unsigned char &role);

	/********************************Set Mic******************************************/
	//NO_TEST_MODE
	RTKANCMPEXPORT_API int RTKSetDualMicStatusByCom(IN const int portIndex, _DUAL_MIC_STATUS_ *info);
	RTKANCMPEXPORT_API int RTKSetDualMicStatusBySPP(IN const unsigned long long addr, _DUAL_MIC_STATUS_ *info);

	/********************************ANC��LL-APT gainmismatch*****************************/
	//ENTER_LLAPT_TEST_MODE
	//one dongle/one uart for one earphone
	RTKANCMPEXPORT_API int RTKANCLLAPTReadGaindBByCom1(
		IN const int portIndex,
		IN const unsigned char target_sel,
		IN OUT _ANC_LLAPT_READ_INFO_* info);
	RTKANCMPEXPORT_API int RTKANCLLAPTReadGaindBBySPP1(
		IN const unsigned long long addr,
		IN const unsigned char target_sel,
		IN OUT _ANC_LLAPT_READ_INFO_* info);

	RTKANCMPEXPORT_API int RTKANCLLAPTWriteGaindBByCom1(IN const int portIndex, IN const _ANC_LLAPT_WRITE_INFO_ info);
	RTKANCMPEXPORT_API int RTKANCLLAPTWriteGaindBBySPP1(IN const unsigned long long addr, IN const _ANC_LLAPT_WRITE_INFO_ info);

	RTKANCMPEXPORT_API int RTKANCLLAPTBurnGaindBByCom1(IN const int portIndex, IN const _ANC_LLAPT_BURN_INFO_ info);
	RTKANCMPEXPORT_API int RTKANCLLAPTBurnGaindBBySPP1(IN const unsigned long long addr, IN const _ANC_LLAPT_BURN_INFO_ info);

	//one dongle/one uart for two earphone
	RTKANCMPEXPORT_API int RTKANCLLAPTReadGaindBByCom2(
		IN const int portIndex,
		IN const unsigned char target_sel,
		IN OUT _ANC_LLAPT_READ_INFO_* info0,
		IN OUT _ANC_LLAPT_READ_INFO_* info1);
	RTKANCMPEXPORT_API int RTKANCLLAPTReadGaindBBySPP2(
		IN const unsigned long long addr,
		IN const unsigned char target_sel,
		IN OUT _ANC_LLAPT_READ_INFO_* info0,
		IN OUT _ANC_LLAPT_READ_INFO_* info1);

	RTKANCMPEXPORT_API int RTKANCLLAPTWriteGaindBByCom2(
		IN const int portIndex,
		IN const _ANC_LLAPT_WRITE_INFO_ info0,
		IN const _ANC_LLAPT_WRITE_INFO_ info1);
	RTKANCMPEXPORT_API int RTKANCLLAPTWriteGaindBBySPP2(
		IN const unsigned long long addr,
		IN const _ANC_LLAPT_WRITE_INFO_ info0,
		IN const _ANC_LLAPT_WRITE_INFO_ info1);

	RTKANCMPEXPORT_API int RTKANCLLAPTBurnGaindBByCom2(
		IN const int portIndex,
		IN const _ANC_LLAPT_BURN_INFO_ info0,
		IN const _ANC_LLAPT_BURN_INFO_ info1);
	RTKANCMPEXPORT_API int RTKANCLLAPTBurnGaindBBySPP2(
		IN const unsigned long long addr,
		IN const _ANC_LLAPT_BURN_INFO_ info0,
		IN const _ANC_LLAPT_BURN_INFO_ info1);

	/********************************ANC and LL-APT gainmismatch*****************************/
	//ENTER_LLAPT_TEST_MODE
	//one dongle/one uart for one earphone
	RTKANCMPEXPORT_API int RTKANCLLAPTBothWriteGaindBByCom1(IN const int portIndex, IN const _ANC_LLAPT_WRITE_INFO_ info);
	RTKANCMPEXPORT_API int RTKANCLLAPTBothWriteGaindBBySPP1(IN const unsigned long long addr, IN const _ANC_LLAPT_WRITE_INFO_ info);

	RTKANCMPEXPORT_API int RTKANCLLAPTBothBurnGaindBByCom1(IN const int portIndex, IN const _ANC_LLAPT_BURN_INFO_ info);
	RTKANCMPEXPORT_API int RTKANCLLAPTBothBurnGaindBBySPP1(IN const unsigned long long addr, IN const _ANC_LLAPT_BURN_INFO_ info);

	//one dongle/one uart for two earphone
	RTKANCMPEXPORT_API int RTKANCLLAPTBothWriteGaindBByCom2(
		IN const int portIndex,
		IN const _ANC_LLAPT_WRITE_INFO_ info0,
		IN const _ANC_LLAPT_WRITE_INFO_ info1);
	RTKANCMPEXPORT_API int RTKANCLLAPTBothWriteGaindBBySPP2(
		IN const unsigned long long addr,
		IN const _ANC_LLAPT_WRITE_INFO_ info0,
		IN const _ANC_LLAPT_WRITE_INFO_ info1);

	RTKANCMPEXPORT_API int RTKANCLLAPTBothBurnGaindBByCom2(
		IN const int portIndex,
		IN const _ANC_LLAPT_BURN_INFO_ info0,
		IN const _ANC_LLAPT_BURN_INFO_ info1);
	RTKANCMPEXPORT_API int RTKANCLLAPTBothBurnGaindBBySPP2(
		IN const unsigned long long addr,
		IN const _ANC_LLAPT_BURN_INFO_ info0,
		IN const _ANC_LLAPT_BURN_INFO_ info1);

	RTKANCMPEXPORT_API int RTKQueryLLAPTGroupInfoByCom(IN const int portIndex, OUT _LLAPT_GROUP_INFO* info);
	RTKANCMPEXPORT_API int RTKQueryLLAPTGroupInfoBySPP(IN const unsigned long long addr, OUT _LLAPT_GROUP_INFO* info);

	/********************************Query group num*************************************/
	RTKANCMPEXPORT_API int RTKQueryANCGroupNumByCom(IN const int portIndex, unsigned char &num);
	RTKANCMPEXPORT_API int RTKQueryANCGroupNumBySPP(IN const unsigned long long addr, unsigned char &num);

	RTKANCMPEXPORT_API int RTKQueryLLAPTGroupNumByCom(IN const int portIndex, unsigned char &num);
	RTKANCMPEXPORT_API int RTKQueryLLAPTGroupNumBySPP(IN const unsigned long long addr, unsigned char &num);


	/*******************************WNS ON/OFF***************************************/
	RTKANCMPEXPORT_API int RTKSetWNSOnOffByCom(
		IN const int portIndex,
		IN int status);//0->off;1->on
		
	RTKANCMPEXPORT_API int RTKSetWNSOnOffBySPP(
		IN const unsigned long long addr, 
		IN int status);


}

#pragma pack(pop)