
1  How to enable and disable trace capture
a.  Run the "MPPGToolAutoLogEnable.cmd" in administrator privilege (right click and select run as administrator) to enable log capture.
b.  Run the MPPG Tool 
c.  After test finished, run the "MPPGToolAutoLogDisable.cmd" in administrator privilege to disable log capture.
d.  Please send files under folder ��C:\ProgramData\Realtek\MPPGTOOLTRACES�� to us (C:\ProgramData is a hidden folder). Please also tell us which time the issue happened.

2   Initial password for MP Setting mode is "1"

